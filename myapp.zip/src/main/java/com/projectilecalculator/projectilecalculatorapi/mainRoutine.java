package com.projectilecalculator.projectilecalculatorapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class mainRoutine {

	public static void main(String[] args) {
		SpringApplication.run(mainRoutine.class, args);
	}

}
